import cryptojs from "crypto-js";
import { type ContextSession, type ContextBase } from "./context.js";
import { FriendEventType } from "./models/FriendEvent.js";
import { GroupEventType } from "./models/GroupEvent.js";
import type { API } from "./zalo.js";
import type { AttachmentSource } from "./models/Attachment.js";
export declare const isBun: boolean;
export declare function hasOwn(obj: Record<string, unknown>, key: string): key is keyof typeof obj;
/**
 * Get signed key for API requests.
 *
 * @param type
 * @param params
 * @returns MD5 hash
 *
 */
export declare function getSignKey(type: string, params: Record<string, unknown>): string;
/**
 *
 * @param baseURL
 * @param params
 * @param apiVersion automatically add zalo api version to url params
 * @returns
 *
 */
export declare function makeURL(ctx: ContextBase, baseURL: string, params?: Record<string, string | number>, apiVersion?: boolean): string;
export declare class ParamsEncryptor {
    private zcid;
    private enc_ver;
    private zcid_ext;
    private encryptKey;
    constructor({ type, imei, firstLaunchTime }: {
        type: number;
        imei: string;
        firstLaunchTime: number;
    });
    getEncryptKey(): string;
    createZcid(type: number, imei: string, firstLaunchTime: number): void;
    createEncryptKey(e?: number): boolean;
    getParams(): {
        zcid: string;
        zcid_ext: string;
        enc_ver: string;
    } | null;
    static processStr(e: string): {
        even: null;
        odd: null;
    } | {
        even: string[];
        odd: string[];
    };
    static randomString(e?: number, t?: number): string;
    static encodeAES(e: string, message: string, type: "hex" | "base64", uppercase: boolean, s?: number): string | null;
}
export declare function decryptResp(key: string, data: string): Record<string, unknown> | null | string;
export declare function decodeBase64ToBuffer(data: string): Buffer;
export declare function decodeUnit8Array(data: Uint8Array): string | null;
export declare function encodeAES(secretKey: string, data: cryptojs.lib.WordArray | string, t?: number): string | null;
export declare function decodeAES(secretKey: string, data: string, t?: number): string | null;
export declare function getDefaultHeaders(ctx: ContextBase, origin?: string): Promise<{
    Accept: string;
    "Accept-Encoding": string;
    "Accept-Language": string;
    "content-type": string;
    Cookie: string;
    Origin: string;
    Referer: string;
    "User-Agent": string;
}>;
export declare function request(ctx: ContextBase, url: string, options?: RequestInit, raw?: boolean): Promise<Response>;
export declare function getImageMetaData(ctx: ContextBase, filePath: string): Promise<{
    fileName: string;
    totalSize: number;
    width: number;
    height: number;
}>;
export declare function getFileSize(filePath: string): Promise<number>;
export declare function getGifMetaData(ctx: ContextBase, filePath: string): Promise<{
    fileName: string;
    totalSize: number;
    width: number;
    height: number;
}>;
export declare function decodeEventData(parsed: Record<string, unknown>, cipherKey?: string): Promise<any>;
export declare function getMd5LargeFileObject(source: AttachmentSource, fileSize: number): Promise<{
    currentChunk: number;
    data: string;
}>;
export declare const logger: (ctx: {
    options: {
        logging?: boolean;
    };
}) => {
    verbose: (...args: unknown[]) => void;
    info: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
    error: (...args: unknown[]) => void;
    success: (...args: unknown[]) => void;
    timestamp: (...args: unknown[]) => void;
};
export declare function getClientMessageType(msgType: string): 1 | 31 | 32 | 44 | 46 | 49 | 36 | 37 | 38 | 43;
export declare function strPadLeft(e: number | string, t: string, n: number): string;
export declare function formatTime(format: string, timestamp?: number): string;
export declare function getFullTimeFromMillisecond(e: number): string;
export declare function getFileExtension(e: string): string;
export declare function getFileName(e: string): string;
export declare function removeUndefinedKeys(e: Record<string, unknown>): Record<string, unknown>;
export declare function getGroupEventType(act: string): GroupEventType;
export declare function getFriendEventType(act: string): FriendEventType;
type ZaloResponse<T> = {
    data: T | null;
    error: {
        message: string;
        code?: number;
    } | null;
};
export declare function handleZaloResponse<T = unknown>(ctx: ContextSession, response: Response, isEncrypted?: boolean): Promise<ZaloResponse<T>>;
export declare function resolveResponse<T = unknown>(ctx: ContextSession, res: Response, cb?: (result: ZaloResponse<unknown>) => T, isEncrypted?: boolean): Promise<T>;
export type FactoryUtils<T> = {
    makeURL: (baseURL: string, params?: Record<string, string | number>, apiVersion?: boolean) => ReturnType<typeof makeURL>;
    encodeAES: (data: cryptojs.lib.WordArray | string, t?: number) => ReturnType<typeof encodeAES>;
    request: (url: string, options?: RequestInit, raw?: boolean) => ReturnType<typeof request>;
    logger: ReturnType<typeof logger>;
    resolve: (res: Response, cb?: (result: ZaloResponse<unknown>) => T, isEncrypted?: boolean) => ReturnType<typeof resolveResponse<T>>;
};
export declare function apiFactory<T>(): <K extends (api: API, ctx: ContextSession, utils: FactoryUtils<T>) => unknown>(callback: K) => (ctx: ContextBase, api: API) => ReturnType<K>;
export declare function generateZaloUUID(userAgent: string): string;
/**
 * Encrypts a 4-digit PIN to a 32-character hex string
 * @param pin 4-digit PIN number
 * @returns 32-character hex string
 */
export declare function encryptPin(pin: string): string;
/**
 * Decrypts a 32-character hex string back to 4-digit PIN
 * Note: This is a one-way hash, so we can only verify if a PIN matches the hash
 * @param encryptedPin 32-character hex string
 * @param pin 4-digit PIN to verify
 * @returns true if the PIN matches the hash
 *
 * @example
 * const encryptedPin = (await api.getHiddenConversations()).pin;
 * checking pin created..
 * const isValid = validatePin(encryptedPin, "1234"); // true if pin created is 1234
 * const isInvalid = validatePin(encryptedPin, "5678"); // false if not pin created is 5678
 */
export declare function validatePin(encryptedPin: string, pin: string): boolean;
/**
 * Converts a hex color code to a negative color number used by Zalo API
 * @param hex Hex color code (e.g. '#00FF00' or '00FF00')
 * @returns Negative color number (e.g. -16711936)
 *
 * @example
 * const negativeColor = hexToNegativeColor('#00FF00'); // Result: -16711936
 */
export declare function hexToNegativeColor(hex: string): number;
/**
 * Converts a negative color number from Zalo API to hex color code
 * @param negativeColor Negative color number (e.g. -16711936)
 * @returns Hex color code (e.g. '#00FF00')
 *
 * @example
 * const hexColor = negativeColorToHex(-16711936); // Result: '#00FF00'
 */
export declare function negativeColorToHex(negativeColor: number): string;
export declare function normalizeHolderName(input?: string): string | undefined;
export {};
